<?php

    require_once 'vendor/autoload.php';

    MercadoPago\SDK::setAccessToken("ACCESS_TOKEN");

?>
