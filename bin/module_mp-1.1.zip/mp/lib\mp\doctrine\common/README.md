# Doctrine Common

[![Build Status](https://github.com/doctrine/common/workflows/Continuous%20Integration/badge.svg)](https://github.com/doctrine/common/actions)
[![codecov](https://codecov.io/gh/doctrine/common/branch/3.1.x/graph/badge.svg)](https://codecov.io/gh/doctrine/common)

The Doctrine Common project is a library that provides extensions to core PHP functionality.

## More resources:

* [Website](https://www.doctrine-project.org/)
* [Documentation](https://www.doctrine-project.org/projects/doctrine-common/en/current/)
* [Downloads](https://github.com/doctrine/common/releases)
