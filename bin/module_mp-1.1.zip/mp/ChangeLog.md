# CHANGELOG MP FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.1.0

Initial version
